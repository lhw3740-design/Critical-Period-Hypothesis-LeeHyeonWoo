#!/usr/bin/env python3
"""탐색적 민감도 분석(계획서 밖, 결과 확인 후 추가). 판정에는 쓰지 않는다.
A. 원어민도 가족과 같은 유성음 구간 자동 검출로 측정 -> 구간 정의 차이의 영향
B. 가족 구간을 좁히거나 넓힘(가운데 60%, 양쪽 20 ms 확장)
C. 포먼트 상한 ±500 Hz (가족·원어민 모두)
실행: python3 sensitivity.py <family_wav_dir> <hb_dir(men/,women/)> <family_formants_corrected.csv> <native_formants_praat.csv> <participants.csv> <gjt_summary.csv> <out_dir>"""
import csv, os, sys, io, contextlib
import numpy as np, parselmouth
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import family_pipeline as fp
from compute_distances import run
fam_dir, hb, fam_csv, nat_csv, part, gjt, out = sys.argv[1:8]
fam = list(csv.DictReader(open(fam_csv))); nat = list(csv.DictReader(open(nat_csv)))
SXF = {"m": "M", "w": "F"}

def meas(snd, a, b, ceil):
    fm = snd.to_formant_burg(time_step=0.01, max_number_of_formants=5, maximum_formant=ceil, window_length=0.025, pre_emphasis_from=50)
    r = {}
    for p in (20, 50, 80):
        t = a + p / 100 * (b - a)
        for k in (1, 2, 3):
            v = fm.get_value_at_time(k, t); r[f"F{k}_{p}"] = "" if v != v else round(v, 1)
    return r

def write(rows, path):
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)

def family(variant, dceil=0):
    rows, cache = [], {}
    for r in fam:
        x = dict(r)
        if r["excluded"]:
            rows.append(x); continue
        snd = cache.setdefault(r["file"], parselmouth.Sound(os.path.join(fam_dir, r["file"] + ".wav")))
        a, b = float(r["start_s"]), float(r["end_s"]); d = b - a
        if variant == "mid60": a, b = a + 0.2 * d, b - 0.2 * d
        if variant == "wide20": a, b = max(0, a - 0.02), min(snd.xmax, b + 0.02)
        if variant == "late20": a = a + 0.2 * d
        x.update(meas(snd, a, b, fp.CEIL[r["sex"]] + dceil)); rows.append(x)
    return rows

def natives(variant, dceil=0):
    rows = []
    for r in nat:
        x = dict(r); snd = parselmouth.Sound(os.path.join(hb, "men" if r["sex"] == "m" else "women", r["file"] + ".wav"))
        a, b = float(r["start_s"]), float(r["end_s"])
        if variant == "voiced":
            runs = fp.voiced_runs(snd, SXF[r["sex"]], vth=0.45)
            if runs: a, b = max(runs, key=lambda q: q[1] - q[0])
        m = meas(snd, a, b, (5000 if r["sex"] == "m" else 5500) + dceil)
        x.update({"praat_" + k: v for k, v in m.items()}); rows.append(x)
    return rows

conds = {
    "기준(논문)": (None, None),
    "A 원어민도 유성음 자동 구간": (None, ("voiced", 0)),
    "B1 가족 구간 가운데 60%": (("mid60", 0), None),
    "B2 가족 구간 양쪽 20ms 확장": (("wide20", 0), None),
    "B3 가족 구간 앞쪽 20% 자름": (("late20", 0), None),
    "C1 포먼트 상한 -500Hz(둘 다)": (("base", -500), ("base", -500)),
    "C2 포먼트 상한 +500Hz(둘 다)": (("base", 500), ("base", 500)),
}
res = []
for name, (fv, nv) in conds.items():
    fpth, npth = fam_csv, nat_csv
    if fv: fpth = f"{out}/fam_tmp.csv"; write(family(*fv), fpth)
    if nv: npth = f"{out}/nat_tmp.csv"; write(natives(*nv), npth)
    with contextlib.redirect_stdout(io.StringIO()):
        _, _, _, p90, _, brow, summ, verdict, _ = run(npth, fpth, part, gjt, out, tag="_tmp")
    row = {"조건": name, "원어민p90_남": round(p90[("m", "static")], 3), "원어민p90_여": round(p90[("w", "static")], 3)}
    for s in summ: row[s["participant"]] = s["static_mean"]
    for s in summ: row[s["participant"] + "_동적"] = s["dynamic_mean"]
    row["아동기평균"] = round((row["P1"] + row["P3"]) / 2, 3); row["성인기평균"] = round((row["P2"] + row["P4"]) / 2, 3)
    row["원어민범위안_블록수"] = sum(b["static_in_native_90pct"] for b in brow)
    row["정적판정"] = verdict["정적 거리"]; row["동적판정"] = verdict["동적 거리(보조)"]
    res.append(row); print(row, flush=True)
write(res, f"{out}/sensitivity_static.csv")
for f in os.listdir(out):
    if "_tmp" in f: os.remove(os.path.join(out, f))
