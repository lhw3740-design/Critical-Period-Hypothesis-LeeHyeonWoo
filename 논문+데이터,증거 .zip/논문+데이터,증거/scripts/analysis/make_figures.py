#!/usr/bin/env python3
"""논문 그림 1(P1~P4와 원어민의 스펙트로그램·포먼트 비교), 그림 2(정규화 모음 공간에서 P1과 원어민 평균).
실행: python3 make_figures.py <family_wav_dir> <hillenbrand_dir(men/, women/)> <family_formants_corrected.csv> <native_formants_praat.csv> <out_dir>"""
import csv, sys, os
import numpy as np, parselmouth, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
plt.rcParams["font.family"] = ["DejaVu Sans", "Noto Sans CJK KR"]; plt.rcParams["axes.unicode_minus"] = False
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from compute_distances import vec, native_reference
fam_dir, nat_dir, fam_csv, nat_csv, out = sys.argv[1:6]
fam = list(csv.DictReader(open(fam_csv))); nat = list(csv.DictReader(open(nat_csv)))
# 원어민 비교 화자: 같은 성별 원어민 중 정적 거리가 중앙값인 화자(남 m22, 여 w27). 가족은 첫 번째 블록.
TALK = {"M": "m22", "F": "w27"}; CEIL = {"M": 5000, "F": 5500}
# 단어: heed(기준) + 그 사람의 모음별 정적 거리가 가장 큰 모음(P1 had, P2 heard, P3·P4 hod)
FIGS = [("P1", "본인", [("heed", "iy"), ("had", "ae")]), ("P2", "아버지", [("heed", "iy"), ("heard", "er")]),
        ("P3", "여동생", [("heed", "iy"), ("hod", "ah")]), ("P4", "어머니", [("heed", "iy"), ("hod", "ah")])]
IPA = {"iy": "i", "ih": "ɪ", "ei": "e", "eh": "ɛ", "ae": "æ", "ah": "ɑ", "aw": "ɔ", "oa": "o", "oo": "ʊ", "uw": "u", "uh": "ʌ", "er": "ɝ"}

def panel(ax, snd, a, b, title, ceil):
    lo, hi = max(0, a - 0.12), min(snd.xmax, b + 0.12); p = snd.extract_part(lo, hi, preserve_times=True)
    sg = p.to_spectrogram(window_length=0.005, maximum_frequency=5000); S = 10 * np.log10(sg.values + 1e-12)
    ax.pcolormesh(sg.xs(), sg.ys(), np.clip(S, S.max() - 50, None), cmap="Greys", shading="nearest")
    fm = snd.to_formant_burg(time_step=0.01, max_number_of_formants=5, maximum_formant=ceil, window_length=0.025, pre_emphasis_from=50)
    ts = np.arange(lo, hi, 0.01)
    for k in (1, 2, 3):
        ax.plot(ts, [fm.get_value_at_time(k, t) for t in ts], ".", color="#d62728", ms=3)
    ax.axvspan(a, b, color="#1f77b4", alpha=0.08); ax.axvline(a, color="#1f77b4", ls="--", lw=1); ax.axvline(b, color="#1f77b4", ls="--", lw=1)
    v = {}
    for q, mk in ((0.2, "^"), (0.5, "o"), (0.8, "s")):
        t = a + q * (b - a); f1, f2 = fm.get_value_at_time(1, t), fm.get_value_at_time(2, t); v[q] = (f1, f2)
        ax.plot([t, t], [f1, f2], mk, color="#1f77b4", ms=8, mec="white", mew=1.2)
    t5 = a + 0.5 * (b - a)
    ax.annotate(f"50%: F1 {v[0.5][0]:.0f} Hz\n       F2 {v[0.5][1]:.0f} Hz", (t5, v[0.5][1]), xytext=(8, 14), textcoords="offset points", fontsize=9,
                bbox=dict(boxstyle="round,pad=0.3", fc="white", ec="#1f77b4", alpha=0.9))
    ax.set_xlim(lo, hi); ax.set_ylim(0, 5000); ax.set_title(title, fontsize=11)
    ax.set_xticks([lo, hi]); ax.set_xticklabels([f"{lo:.2f}", f"{hi:.2f} s"], fontsize=8)

for k, (P, who, words) in enumerate(FIGS):
    sx = "M" if P in ("P1", "P2") else "F"; TALKER, BLOCK = TALK[sx], P + "_b01"
    fig, axs = plt.subplots(2, 2, figsize=(11, 7.6), sharey=True)
    fs = parselmouth.Sound(os.path.join(fam_dir, BLOCK + ".wav"))
    for i, (w, code) in enumerate(words):
        r = next(x for x in fam if x["file"] == BLOCK and x["word"] == w)
        panel(axs[i, 0], fs, float(r["start_s"]), float(r["end_s"]), f"{P} ({who}) · {w} /{IPA[code]}/", CEIL[sx])
        n = next(x for x in nat if x["talker"] == TALKER and x["vowel"] == code)
        ns = parselmouth.Sound(os.path.join(nat_dir, "men" if sx == "M" else "women", f"{TALKER}{code}.wav"))
        panel(axs[i, 1], ns, float(n["start_s"]), float(n["end_s"]), f"원어민 {'남성' if sx == 'M' else '여성'} {TALKER} · {w} /{IPA[code]}/", CEIL[sx])
    for ax in axs[:, 0]: ax.set_ylabel("주파수 (Hz)")
    fig.suptitle(f"같은 단어의 스펙트로그램과 포먼트: {P} 대 원어민(Hillenbrand 1995)", fontsize=13, y=0.995)
    fig.text(0.5, 0.005, f"빨간 점: Praat Burg 포먼트(F1·F2·F3, 상한 {CEIL[sx]} Hz)   파란 점선: 모음 구간   ▲●■: 측정 지점 20·50·80%   설정은 두 화자 모두 같음",
             ha="center", fontsize=9, color="#444")
    name = "fig1_spectrogram_P1_vs_native.png" if P == "P1" else f"fig1{'bcd'[k - 1]}_spectrogram_{P}_vs_native.png"
    plt.tight_layout(rect=(0, 0.02, 1, 0.97)); plt.savefig(os.path.join(out, name), dpi=150); plt.close()

# 그림 4: Lobanov z 공간. 원어민 남성 45명의 모음별 평균(회색), P1 블록 3개의 평균(파랑), 그 사이 선 = 모음별 정적 거리
nz, mean_pt, mean_dy = native_reference(nat)
blocks = {}
for r in fam:
    if r["participant"] == "P1": blocks.setdefault(r["block"], []).append(r)
zb = [vec(rs, "") for rs in blocks.values()]
fig, ax = plt.subplots(figsize=(8, 7))
for (s, t), tz in nz.items():
    if s != "m": continue
    for v in tz: ax.plot(tz[v][0][1], tz[v][0][0], ".", color="#bbbbbb", ms=3, zorder=1)
for v, ipa in IPA.items():
    nm = mean_pt[("m", v)]; pm = np.mean([z[v][0] for z in zb], axis=0); d = np.mean([np.linalg.norm(z[v][0] - nm) for z in zb])
    ax.plot([nm[1], pm[1]], [nm[0], pm[0]], "-", color="#1f77b4", lw=1, alpha=0.6, zorder=2)
    ax.plot(nm[1], nm[0], "o", color="#555555", ms=9, zorder=3); ax.text(nm[1], nm[0], ipa, color="white", fontsize=8, ha="center", va="center", zorder=4)
    ax.plot(pm[1], pm[0], "o", color="#1f77b4", ms=9, zorder=3); ax.text(pm[1], pm[0], ipa, color="white", fontsize=8, ha="center", va="center", zorder=4)
    if d > 1.0: ax.annotate(f"{ipa} 거리 {d:.2f}", (pm[1], pm[0]), fontsize=9, color="#1f77b4", xytext=(10, 10), textcoords="offset points",
                            bbox=dict(boxstyle="round,pad=0.2", fc="white", ec="none", alpha=0.85))
ax.invert_xaxis(); ax.invert_yaxis()
ax.set_xlabel("정규화 F2 (z)      ← 앞쪽 모음 (전설)            뒤쪽 모음 (후설) →"); ax.set_ylabel("정규화 F1 (z)   위 = 혀 높음(고모음), 아래 = 혀 낮음(저모음)")
ax.set_title("정적 거리를 재는 방법: 모음별로 P1 평균(파랑)과 원어민 남성 평균(회색)의 거리\n(작은 회색 점 = 원어민 남성 45명 개인값, 숫자 = 거리가 1.0을 넘는 모음)", fontsize=11)
ax.grid(alpha=0.25); plt.tight_layout(); plt.savefig(os.path.join(out, "fig2_vowel_space_P1_vs_native.png"), dpi=150); plt.close()
print("ok")
