#!/usr/bin/env python3
"""Hillenbrand et al. (1995) 성인 남녀 음성 재측정 (계획서 4절 설정).

입력: <data_dir>/men/*.wav, women/*.wav, dat/timedata.dat, dat/vowdata.dat
출력: <out_csv>  (파일마다 20/50/80% 지점 F1·F2·F3, 공개 수치 병기)
설정: Burg, 시간 간격 0.01 s, 최대 포먼트 5개, 분석 창 0.025 s, 선강조 50 Hz,
      상한 남성 5000 Hz / 여성 5500 Hz.  모음 구간은 timedata.dat의 Start~End(ms).
도구: Python parselmouth 0.4.7 (내장 Praat 엔진 6.1.38). 가족 녹음도 같은 설정으로 측정한다.
실행: python3 measure_natives.py <data_dir> <out_csv>
"""
import csv, re, sys
from pathlib import Path
import parselmouth

STEP, NFORM, WIN, PREEMPH = 0.01, 5.0, 0.025, 50.0
CEIL = {"m": 5000.0, "w": 5500.0}
PTS = (0.2, 0.5, 0.8)


def read_table(path, ncol):
    rows = {}
    for line in Path(path).read_text().splitlines():
        if re.match(r"^[mwbg]\d\d\w\w\s", line):
            f = line.split()
            assert len(f) == ncol, (path, line)
            rows[f[0]] = f
    return rows


def main(data_dir, out_csv):
    d = Path(data_dir)
    tim = read_table(d / "dat/timedata.dat", 5)
    vow = read_table(d / "dat/vowdata.dat", 16)
    out = []
    for name in sorted(tim):
        if name[0] not in "mw":          # 아이(b, g)는 사용하지 않음
            continue
        sex = name[0]
        wav = d / ("men" if sex == "m" else "women") / f"{name}.wav"
        snd = parselmouth.Sound(str(wav))
        fm = snd.to_formant_burg(time_step=STEP, max_number_of_formants=NFORM,
                                 maximum_formant=CEIL[sex], window_length=WIN,
                                 pre_emphasis_from=PREEMPH)
        start, end = float(tim[name][1]) / 1000, float(tim[name][2]) / 1000
        row = {"file": name, "sex": sex, "vowel": name[3:5], "talker": name[:3],
               "start_s": start, "end_s": end}
        for p in PTS:
            t = start + p * (end - start)
            for k in (1, 2, 3):
                v = fm.get_value_at_time(k, t)
                row[f"praat_F{k}_{int(p*100)}"] = "" if v != v else round(v, 1)
        v = vow[name]   # 공개 수치: 20% = col8-10, 50% = col11-13, 80% = col14-16
        for i, p in enumerate((20, 50, 80)):
            for k in range(3):
                x = float(v[7 + 3 * i + k])
                row[f"pub_F{k+1}_{p}"] = "" if x == 0 else x
        out.append(row)
    with open(out_csv, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(out[0].keys()))
        w.writeheader(); w.writerows(out)
    print(f"parselmouth {parselmouth.__version__} / Praat {parselmouth.PRAAT_VERSION}: {len(out)}행 -> {out_csv}")


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
