#!/usr/bin/env python3
"""계획서 8절 2번: Hillenbrand 공개 수치(vowdata.dat)와 parselmouth 재측정 값의 차이. 공개 값 0(측정 없음)은 뺀다.
실행: python3 compare_public.py <native_formants_praat.csv> <out_csv>"""
import csv, sys, statistics as st
rows = list(csv.DictReader(open(sys.argv[1])))
out = []
for sx in ("m", "w"):
    for v in sorted({r["vowel"] for r in rows}) + ["ALL"]:
        for k in ("F1_50", "F2_50"):
            d = [float(r["praat_" + k]) - float(r["pub_" + k]) for r in rows if r["sex"] == sx and (v == "ALL" or r["vowel"] == v)
                 and r["praat_" + k] and r["pub_" + k] and float(r["pub_" + k]) > 0]
            out.append({"sex": sx, "vowel": v, "measure": k, "n": len(d), "mean_diff_hz": round(st.mean(d), 1),
                        "median_abs_diff_hz": round(st.median(abs(x) for x in d), 1),
                        "pct_abs_diff_gt_10pct": round(100 * sum(abs(x) > 0.1 * float(r["pub_" + k]) for x, r in zip(d, [r for r in rows if r["sex"] == sx and (v == "ALL" or r["vowel"] == v) and r["praat_" + k] and r["pub_" + k] and float(r["pub_" + k]) > 0])) / len(d), 1)})
with open(sys.argv[2], "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(out[0])); w.writeheader(); w.writerows(out)
for o in out:
    if o["vowel"] == "ALL" or o["median_abs_diff_hz"] > 60: print(o)
