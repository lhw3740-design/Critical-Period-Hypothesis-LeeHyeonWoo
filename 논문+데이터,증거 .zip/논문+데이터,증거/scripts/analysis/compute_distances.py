#!/usr/bin/env python3
"""정적·동적 음향 거리와 계획서 5절 판정 규칙 적용 (계획서 4절 + 블록 단위 계산).

입력: native_formants_praat.csv(원어민 재측정), family_formants.csv(가족), participants.csv, gjt_summary.csv
정규화: 화자(원어민) 또는 블록(가족)의 12모음 50% 지점 F1, F2 각각의 평균·표준편차(모집단 SD)로 Lobanov z.
정적 거리: 모음별 (zF1_50, zF2_50)과 같은 성별 원어민 평균점의 유클리드 거리를 12모음에 걸쳐 평균.
동적 거리: 모음별 (z80 - z20)(F1, F2)과 같은 성별 원어민 평균 변화량의 유클리드 거리를 12모음에 걸쳐 평균.
원어민 평균점·변화량: 같은 성별 원어민 전체(남 45, 여 48)의 모음별 평균(계획서 그대로, 본인 포함).
"원어민 범위 안": 블록 거리가 같은 성별 원어민 거리 분포의 90백분위 이하.
판정(계획서 5절): 지표마다 아동기(P1, P3) vs 성인기(P2, P4)를 비교한다.
  방향 일치 = 아동기 두 사람이 성인기 두 사람보다 모두 좋음 / 부분 일치 = 평균은 좋지만 범위가 겹침 / 불일치 = 아동기 평균이 같거나 나쁨
  가설 전체: GJT 정확도와 정적 거리가 모두 방향 일치면 지지, 하나만 방향 일치하거나 둘 다 부분 일치면 부분 지지, 둘 다 불일치면 기각.
실행: python3 compute_distances.py <native_csv> <family_csv> <participants_csv> <gjt_summary_csv> <out_dir>
"""
import csv, sys
from collections import defaultdict
import numpy as np

V = ["iy", "ih", "ei", "eh", "ae", "ah", "aw", "oa", "oo", "uw", "uh", "er"]


def vec(rows, pre):
    """한 화자/블록의 행들 -> {모음: (z50, z20, z80)} (각각 [F1, F2])"""
    d = {r["vowel"]: r for r in rows}
    keys = [f"{pre}F{k}_{p}" for k in (1, 2) for p in (20, 50, 80)]
    ok = [v for v in V if v in d and all(d[v][k] != "" for k in keys)]
    f = lambda r, k, p: float(r[f"{pre}F{k}_{p}"])
    m = [np.mean([f(d[v], k, 50) for v in ok]) for k in (1, 2)]
    s = [np.std([f(d[v], k, 50) for v in ok]) for k in (1, 2)]
    z = lambda v, p: np.array([(f(d[v], k, p) - m[k - 1]) / s[k - 1] for k in (1, 2)])
    return {v: (z(v, 50), z(v, 20), z(v, 80)) for v in ok}


def native_reference(nat_rows):
    by_t = defaultdict(list)
    for r in nat_rows:
        by_t[(r["sex"], r["talker"])].append(r)
    nz = {k: vec(rs, "praat_") for k, rs in by_t.items()}
    mean_pt, mean_dy = {}, {}
    for sx in "mw":
        for v in V:
            mean_pt[(sx, v)] = np.mean([t[v][0] for (s, _), t in nz.items() if s == sx and v in t], axis=0)
            mean_dy[(sx, v)] = np.mean([t[v][2] - t[v][1] for (s, _), t in nz.items() if s == sx and v in t], axis=0)
    return nz, mean_pt, mean_dy


def vowel_dists(tz, sx, mean_pt, mean_dy):
    return {v: (float(np.linalg.norm(tz[v][0] - mean_pt[(sx, v)])),
                float(np.linalg.norm((tz[v][2] - tz[v][1]) - mean_dy[(sx, v)]))) for v in tz}


def judge(child, adult, higher_better):
    """child, adult: 값 리스트. 반환 '방향 일치' / '부분 일치' / '불일치'"""
    sgn = 1 if higher_better else -1
    c, a = [sgn * x for x in child], [sgn * x for x in adult]
    if min(c) > max(a):
        return "방향 일치"
    if np.mean(c) > np.mean(a):
        return "부분 일치"
    return "불일치"


def overall(j_gjt, j_static):
    if j_gjt == "방향 일치" and j_static == "방향 일치":
        return "지지"
    if (j_gjt == "방향 일치") != (j_static == "방향 일치"):
        return "부분 지지"
    if j_gjt == "부분 일치" and j_static == "부분 일치":
        return "부분 지지"
    if j_gjt == "불일치" and j_static == "불일치":
        return "기각"
    return "규칙에 정의 없음(" + j_gjt + " / " + j_static + ")"


def run(nat_csv, fam_csv, part_csv, gjt_csv, out_dir, tag=""):
    nat = list(csv.DictReader(open(nat_csv))); fam = list(csv.DictReader(open(fam_csv)))
    part = {r["participant"]: r for r in csv.DictReader(open(part_csv, encoding="utf-8"))}
    gjt = {r["participant"]: float(r["accuracy"]) for r in csv.DictReader(open(gjt_csv))}
    nz, mean_pt, mean_dy = native_reference(nat)
    nrows = []
    for (sx, t), tz in sorted(nz.items()):
        vd = vowel_dists(tz, sx, mean_pt, mean_dy)
        nrows.append({"sex": sx, "talker": t, "static": float(np.mean([a for a, _ in vd.values()])),
                      "dynamic": float(np.mean([b for _, b in vd.values()])), "n_vowels": len(vd)})
    p90 = {(sx, k): float(np.percentile([r[k] for r in nrows if r["sex"] == sx], 90)) for sx in "mw" for k in ("static", "dynamic")}
    med = {(sx, k): float(np.median([r[k] for r in nrows if r["sex"] == sx])) for sx in "mw" for k in ("static", "dynamic")}

    by_b = defaultdict(list)
    for r in fam:
        by_b[(r["participant"], r["block"])].append(r)
    brow, vrow = [], []
    for (p, b), rs in sorted(by_b.items()):
        sx = "m" if rs[0]["sex"] == "M" else "w"
        tz = vec(rs, ""); vd = vowel_dists(tz, sx, mean_pt, mean_dy)
        s = float(np.mean([a for a, _ in vd.values()])); d = float(np.mean([c for _, c in vd.values()]))
        brow.append({"participant": p, "block": b, "sex": sx, "static": round(s, 4), "dynamic": round(d, 4), "n_vowels": len(vd),
                     "static_in_native_90pct": int(s <= p90[(sx, "static")]), "dynamic_in_native_90pct": int(d <= p90[(sx, "dynamic")])})
        for v, (a, c) in vd.items():
            vrow.append({"participant": p, "block": b, "vowel": v, "static": round(a, 4), "dynamic": round(c, 4)})

    summ = []
    for p in ["P1", "P2", "P3", "P4"]:
        bs = [r for r in brow if r["participant"] == p]
        summ.append({"participant": p, "role": part[p]["role"], "arrival_group": part[p]["arrival_group"],
                     "usage_group": part[p]["usage_group"], "gjt_accuracy": gjt[p],
                     "static_mean": round(float(np.mean([r["static"] for r in bs])), 4),
                     "static_min": min(r["static"] for r in bs), "static_max": max(r["static"] for r in bs),
                     "dynamic_mean": round(float(np.mean([r["dynamic"] for r in bs])), 4),
                     "dynamic_min": min(r["dynamic"] for r in bs), "dynamic_max": max(r["dynamic"] for r in bs),
                     "blocks_static_in_native_90pct": sum(r["static_in_native_90pct"] for r in bs),
                     "blocks_dynamic_in_native_90pct": sum(r["dynamic_in_native_90pct"] for r in bs)})
    grp = lambda key, g: [r[key] for r in summ if r["arrival_group"] == g]
    verdict = {
        "GJT 정확도": judge(grp("gjt_accuracy", "child"), grp("gjt_accuracy", "adult"), True),
        "정적 거리": judge(grp("static_mean", "child"), grp("static_mean", "adult"), False),
        "동적 거리(보조)": judge(grp("dynamic_mean", "child"), grp("dynamic_mean", "adult"), False),
    }
    verdict["가설 전체"] = overall(verdict["GJT 정확도"], verdict["정적 거리"])

    for name, rows in (("native_distances", nrows), ("family_block_distances", brow), ("family_vowel_distances", vrow), ("family_participant_summary", summ)):
        with open(f"{out_dir}/{name}{tag}.csv", "w", newline="", encoding="utf-8") as fh:
            w = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); w.writeheader()
            for r in rows:
                w.writerow({k: (round(x, 4) if isinstance(x, float) else x) for k, x in r.items()})
    return nz, mean_pt, mean_dy, p90, med, brow, summ, verdict, by_b


if __name__ == "__main__":
    nat_csv, fam_csv, part_csv, gjt_csv, out_dir = sys.argv[1:6]
    nz, mean_pt, mean_dy, p90, med, brow, summ, verdict, by_b = run(nat_csv, fam_csv, part_csv, gjt_csv, out_dir)
    print("원어민 거리(남 m 45, 여 w 48): 90백분위 / 중앙값")
    for sx in "mw":
        print(" ", sx, {k: (round(p90[(sx, k)], 3), round(med[(sx, k)], 3)) for k in ("static", "dynamic")})
    print("\n가족 블록별")
    for r in brow:
        print(" ", r)
    print("\n참여자 요약")
    for r in summ:
        print(" ", r)
    print("\n판정(계획서 5절)")
    for k, v in verdict.items():
        print(f"  {k}: {v}")
    # 라벨 정렬 점검(진단용): 같은 사람 안에서, 한 블록의 각 모음을 '나머지 2블록의 모음별 평균점'과 비교해 가장 가까운 모음이 기대 모음과 같은지
    print("\n라벨 정렬 점검(leave-one-block-out 최근접 모음 일치율, 우연 수준 1/12=0.08)")
    with open(f"{out_dir}/label_check.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh); w.writerow(["participant", "hits", "total", "rate"])
        for p in ["P1", "P2", "P3", "P4"]:
            zs = {b: vec(rs, "") for (pp, b), rs in by_b.items() if pp == p}; hit = tot = 0
            for b, tz in zs.items():
                cent = {v: np.mean([zz[v][0] for bb, zz in zs.items() if bb != b and v in zz], axis=0) for v in V}
                for v, (z50, _, _) in tz.items():
                    hit += min(V, key=lambda u: np.linalg.norm(z50 - cent[u])) == v; tot += 1
            w.writerow([p, hit, tot, round(hit / tot, 3)]); print(f"  {p} {hit}/{tot} = {hit / tot:.2f}")
