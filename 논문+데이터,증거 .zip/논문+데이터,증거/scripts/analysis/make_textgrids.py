#!/usr/bin/env python3
"""자동 검출한 12개 모음 구간으로 블록별 TextGrid('vowel' 층, 단어 라벨)를 만든다. 연구자가 Praat에서 경계를 고치는 용도.
실행: python3 make_textgrids.py <wav_dir> <recording_lists.csv> <out_dir>"""
import csv, glob, os, sys
import parselmouth
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from family_pipeline import detect12, SEX
wav_dir, list_csv, out = sys.argv[1:4]; os.makedirs(out, exist_ok=True)
lst = list(csv.DictReader(open(list_csv, encoding="utf-8")))
for p in sorted(glob.glob(os.path.join(wav_dir, "*.wav"))):
    name = os.path.basename(p)[:-4]; part, blk = name.split("_")[:2]
    snd = parselmouth.Sound(p); runs, _ = detect12(snd, SEX[part]); dur = snd.xmax
    words = [r["word"] for r in lst if r["participant"] == part and r["block"] == blk]
    iv, t0 = [], 0.0
    for (a, b), w in zip(runs, words):
        iv += [(t0, a, ""), (a, b, w)]; t0 = b
    iv.append((t0, dur, ""))
    s = 'File type = "ooTextFile"\nObject class = "TextGrid"\n\nxmin = 0\nxmax = %.6f\ntiers? <exists>\nsize = 1\nitem []:\n    item [1]:\n        class = "IntervalTier"\n        name = "vowel"\n        xmin = 0\n        xmax = %.6f\n        intervals: size = %d\n' % (dur, dur, len(iv))
    for i, (a, b, w) in enumerate(iv, 1):
        s += '        intervals [%d]:\n            xmin = %.6f\n            xmax = %.6f\n            text = "%s"\n' % (i, a, b, w)
    open(os.path.join(out, name + ".TextGrid"), "w", encoding="utf-8").write(s)
print("done", len(glob.glob(out + "/*.TextGrid")))
