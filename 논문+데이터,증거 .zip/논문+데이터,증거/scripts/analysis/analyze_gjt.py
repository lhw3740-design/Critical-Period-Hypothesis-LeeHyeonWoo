#!/usr/bin/env python3
"""GJT 분석 (계획서 8절 1번): 참여자별 정확도, 정문·비문 정확도, 범주별 정확도, 반응시간 중앙값.
입력: <gjt_dir>/P*_gjt_*.csv, gjt_sentences.csv   출력: <out_dir>/gjt_*.csv
분석 대상: block == main 의 55문장(전부). 정답은 정문(1)이면 f, 비문(0)이면 j. 반응시간: 정답 시행의 중앙값(초), 제외 없음.
보조(계획서 밖, 결과 확인 후 추가): 정확도의 이항 95% 신뢰구간(Clopper-Pearson), 신호탐지 d'와 기준 c(log-linear 보정).
실행: python3 analyze_gjt.py <gjt_dir> <gjt_sentences.csv> <out_dir>
"""
import csv, glob, statistics as st, sys
from collections import defaultdict
from pathlib import Path
from scipy.stats import beta, norm

gjt_dir, sent_csv, out_dir = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
out_dir.mkdir(exist_ok=True)
sent = {r["sentence_id"]: r for r in csv.DictReader(open(sent_csv, encoding="utf-8"))}
rows = []
for f in sorted(glob.glob(str(gjt_dir / "P*_gjt_*.csv"))):
    rows += list(csv.DictReader(open(f, encoding="utf-8")))

# 점검 1: 입력 CSV의 정답 열을 정답표에서 다시 계산해 대조한다
bad = 0
for r in rows:
    g = int(sent[r["sentence_id"]]["grammatical"])
    resp = 1 if r["key"] == "f" else 0
    if int(r["grammatical"]) != g or int(r["response_grammatical"]) != resp or int(r["correct"]) != int(resp == g):
        bad += 1
print("correct 재계산 불일치:", bad)
assert bad == 0

main = [r for r in rows if r["block"] == "main"]
by_p = defaultdict(list)
for r in main:
    by_p[r["participant"]].append(r)
assert sorted(by_p) == ["P1", "P2", "P3", "P4"], sorted(by_p)
for p, rs in sorted(by_p.items()):
    ids = [r["sentence_id"] for r in rs]
    assert len(rs) == 55 and len(set(ids)) == 55, (p, len(rs), len(set(ids)))
    assert sum(int(r["grammatical"]) for r in rs) == 28
print("참여자별 본 시행 55건·문장 중복 없음·정문 28 확인")
print("세션 시드:", {p: rs[0]["seed"] for p, rs in sorted(by_p.items())}, "| PsychoPy:", {p: rs[0]["psychopy_version"] for p, rs in sorted(by_p.items())})
print("연습 행 수:", {p: sum(1 for r in rows if r["participant"] == p and r["block"] == "practice") for p in sorted(by_p)})


def acc(rs):
    return sum(int(r["correct"]) for r in rs) / len(rs) if rs else float("nan")


def cp_ci(k, n, a=0.05):
    lo = 0.0 if k == 0 else beta.ppf(a / 2, k, n - k + 1)
    hi = 1.0 if k == n else beta.ppf(1 - a / 2, k + 1, n - k)
    return lo, hi


with open(out_dir / "gjt_summary.csv", "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow(["participant", "n", "accuracy", "n_correct", "acc_ci95_lo", "acc_ci95_hi", "grammatical_acc", "ungrammatical_acc",
                "pct_resp_grammatical", "dprime_loglinear", "criterion_c", "rt_median_correct_s", "rt_median_all_s", "rt_le_0.15s_n"])
    for p, rs in sorted(by_p.items()):
        g = [r for r in rs if r["grammatical"] == "1"]; u = [r for r in rs if r["grammatical"] == "0"]
        hit = sum(1 for r in g if r["response_grammatical"] == "1"); fa = sum(1 for r in u if r["response_grammatical"] == "1")
        zh, zf = norm.ppf((hit + .5) / (len(g) + 1)), norm.ppf((fa + .5) / (len(u) + 1))
        k = sum(int(r["correct"]) for r in rs); lo, hi = cp_ci(k, len(rs))
        rtc = [float(r["rt_s"]) for r in rs if r["correct"] == "1"]; rta = [float(r["rt_s"]) for r in rs]
        w.writerow([p, len(rs), f"{acc(rs):.4f}", k, f"{lo:.3f}", f"{hi:.3f}", f"{acc(g):.4f}", f"{acc(u):.4f}",
                    f"{sum(r['response_grammatical'] == '1' for r in rs) / len(rs):.4f}", f"{zh - zf:.2f}", f"{-0.5 * (zh + zf):.2f}",
                    f"{st.median(rtc):.3f}", f"{st.median(rta):.3f}", sum(x <= 0.15 for x in rta)])
cats = sorted({r["category"] for r in main})
with open(out_dir / "gjt_by_category.csv", "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow(["category", "n_items"] + sorted(by_p))
    for c in cats:
        n = sum(1 for r in by_p["P1"] if r["category"] == c)
        w.writerow([c, n] + [f"{acc([r for r in by_p[p] if r['category'] == c]):.3f}" for p in sorted(by_p)])
with open(out_dir / "gjt_by_sentence.csv", "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow(["sentence_id", "grammatical", "category", "n_correct_of_4"] + sorted(by_p) + ["text"])
    for sid in sorted({r["sentence_id"] for r in main}):
        rr = {r["participant"]: r for r in main if r["sentence_id"] == sid}
        w.writerow([sid, rr["P1"]["grammatical"], rr["P1"]["category"], sum(int(x["correct"]) for x in rr.values())] +
                   [rr[p]["correct"] for p in sorted(by_p)] + [rr["P1"]["text"]])
print(open(out_dir / "gjt_summary.csv").read())
print(open(out_dir / "gjt_by_category.csv").read())
