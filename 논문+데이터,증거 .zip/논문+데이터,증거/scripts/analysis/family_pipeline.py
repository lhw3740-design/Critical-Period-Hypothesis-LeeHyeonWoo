#!/usr/bin/env python3
"""가족 녹음(블록별 12단어)에서 모음 구간을 찾고 F1·F2를 측정하는 함수 모음.
도구: Python parselmouth 0.4.7 (내장 Praat 엔진 6.1.38).

모음 구간(후보): Praat 피치(자기상관) 유성음 구간. 한 단어에서 유성음 연속 구간 하나를 모음 구간으로 본다.
  - 피치 범위: 남 70~300 Hz, 여 120~500 Hz / 간격 0.15 s 이하는 합침 / 0.10 s 미만은 버림
  - 유성 문턱은 0.6, 0.5, 0.45, 0.4, 0.35, 0.3, 0.25 순서로 시도해 구간이 정확히 12개가 되는 가장 높은 값을 쓴다(detect12).
    12개가 되는 값이 없으면 CHECK(이름 안 붙임). 12개이면 recording_lists.csv의 순서대로 단어 이름을 붙인다.
  - 이 규칙은 녹음 파일을 받은 뒤, 포먼트·거리 값을 계산하기 전에 정했다(구간 개수와 스펙트로그램만 보고 정함).
포먼트: 원어민 재측정과 같은 설정(Burg, 0.01 s, 5개, 창 0.025 s, 선강조 50 Hz, 상한 남 5000/여 5500 Hz).
측정 지점: 모음 구간의 20·50·80%.
"""
import parselmouth

STEP, NFORM, WIN, PREEMPH = 0.01, 5.0, 0.025, 50.0
CEIL = {"M": 5000.0, "F": 5500.0}
PITCH = {"M": (70, 300), "F": (120, 500)}
SEX = {"P1": "M", "P2": "M", "P3": "F", "P4": "F"}
THRESHOLDS = (0.6, 0.5, 0.45, 0.4, 0.35, 0.3, 0.25)


def voiced_runs(snd, sex, vth=0.5, minlen=0.10, fill=0.15):
    fl, ce = PITCH[sex]
    pit = snd.to_pitch_ac(time_step=0.01, pitch_floor=fl, pitch_ceiling=ce, silence_threshold=0.03,
                          voicing_threshold=vth, octave_cost=0.05, octave_jump_cost=0.5, voiced_unvoiced_cost=0.2)
    f = pit.selected_array["frequency"]; t = pit.xs(); v = f > 0
    out, i = [], 0
    while i < len(v):
        if v[i]:
            j = i
            while j + 1 < len(v) and v[j + 1]:
                j += 1
            out.append([t[i], t[j]]); i = j + 1
        else:
            i += 1
    m = []
    for s in out:
        if m and s[0] - m[-1][1] < fill:
            m[-1][1] = s[1]
        else:
            m.append(s)
    return [(float(a), float(b)) for a, b in m if b - a >= minlen]


def detect12(snd, sex):
    """(구간 목록, 사용한 문턱) - 12개가 되는 문턱이 없으면 (None, None)"""
    for v in THRESHOLDS:
        r = voiced_runs(snd, sex, vth=v)
        if len(r) == 12:
            return r, v
    return None, None


def make_formant(snd, sex):
    return snd.to_formant_burg(time_step=STEP, max_number_of_formants=NFORM, maximum_formant=CEIL[sex],
                               window_length=WIN, pre_emphasis_from=PREEMPH)


def formants_at(snd, sex, start, end, fm=None):
    fm = fm or make_formant(snd, sex)
    res = {}
    for p in (20, 50, 80):
        t = start + p / 100 * (end - start)
        for k in (1, 2, 3):
            v = fm.get_value_at_time(k, t)
            res[f"F{k}_{p}"] = "" if v != v else round(v, 1)
    return res
