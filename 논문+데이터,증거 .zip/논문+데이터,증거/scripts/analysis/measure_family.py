#!/usr/bin/env python3
"""가족 녹음 측정: 파일마다 12개 모음 구간을 찾고(family_pipeline.detect12) 20·50·80% 지점 F1·F2·F3를 기록한다.
구간 소스 두 가지:
  (기본) 자동: detect12
  (--textgrids DIR) 사람이 고친 TextGrid의 'vowel' 층(라벨이 있는 구간 12개)을 사용. DIR에 TextGrid가 없는 파일은 자동 구간을 쓴다
  (--exclude CSV) file,position,reason 목록의 토큰은 포먼트 값을 비우고 excluded 열에 이유를 적는다(계획서 8절 5번)
실행: python3 measure_family.py <wav_dir> <recording_lists.csv> <out_csv> [--textgrids DIR] [--exclude CSV]
"""
import csv, glob, os, re, sys
import parselmouth
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from family_pipeline import detect12, formants_at, make_formant, SEX


def read_textgrid_vowel(path):
    """long-format TextGrid에서 'vowel' 층의 라벨 있는 구간 목록 [(xmin, xmax, label)]"""
    txt = open(path, encoding="utf-8").read()
    tier = re.split(r'item \[\d+\]:', txt)
    for t in tier:
        if 'name = "vowel"' in t:
            return [(float(a), float(b), s) for a, b, s in
                    re.findall(r'xmin = ([\d.eE+-]+)\s+xmax = ([\d.eE+-]+)\s+text = "([^"]*)"', t) if s.strip()]
    raise ValueError("vowel 층 없음: " + path)


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    tg_dir, excl = None, {}
    if "--textgrids" in sys.argv:
        tg_dir = sys.argv[sys.argv.index("--textgrids") + 1]; args.remove(tg_dir)
    if "--exclude" in sys.argv:
        ex = sys.argv[sys.argv.index("--exclude") + 1]; args.remove(ex)
        excl = {(r["file"], int(r["position"])): r["reason"] for r in csv.DictReader(open(ex, encoding="utf-8"))}
    wav_dir, list_csv, out_csv = args[:3]
    lst = list(csv.DictReader(open(list_csv, encoding="utf-8")))
    rows, flags = [], []
    for p in sorted(glob.glob(os.path.join(wav_dir, "*.wav"))):
        name = os.path.basename(p)[:-4]; part, blk = name.split("_")[0], name.split("_")[1]
        sex = SEX[part]; snd = parselmouth.Sound(p)
        exp = [r for r in lst if r["participant"] == part and r["block"] == blk]
        assert len(exp) == 12, name
        if tg_dir and os.path.exists(os.path.join(tg_dir, name + ".TextGrid")):
            segs = read_textgrid_vowel(os.path.join(tg_dir, name + ".TextGrid"))
            if [s[2] for s in segs] != [e["word"] for e in exp]:
                flags.append(name); print("CHECK(라벨 순서가 목록과 다름):", name); continue
            runs, vth = [(a, b) for a, b, _ in segs], "textgrid"
        else:
            runs, vth = detect12(snd, sex)
            if runs is None:
                flags.append(name); print("CHECK:", name); continue
        fm = make_formant(snd, sex)
        for i, ((a, b), e) in enumerate(zip(runs, exp), 1):
            f = formants_at(snd, sex, a, b, fm)
            why = excl.get((name, i), "")
            if why:
                f = {k: "" for k in f}
            rows.append({"participant": part, "sex": sex, "block": blk, "file": name, "position": i, "word": e["word"],
                         "vowel": e["vowel_code"], "start_s": round(a, 3), "end_s": round(b, 3),
                         "dur_ms": round((b - a) * 1000), "vth": vth, **f, "excluded": why})
    with open(out_csv, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    print(f"{len(rows)}행 -> {out_csv}; CHECK 파일: {flags or '없음'}")


if __name__ == "__main__":
    main()
