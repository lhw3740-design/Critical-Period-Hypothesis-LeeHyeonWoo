#!/usr/bin/env python3
"""GJT 문장 음성 생성 스크립트

gjt_sentences.csv의 문장을 gTTS(영어, 미국식 억양 tld='com')로 mp3로 만들고,
ffmpeg로 44.1 kHz 모노 wav로 바꾸면서 음량을 맞춘 뒤,
문장별 길이·해시·생성 환경을 audio/manifest.csv에 기록한다.

준비:
    python3 -m pip install gTTS imageio-ffmpeg
    (시스템에 ffmpeg가 이미 있으면 그것을 쓰고, 없으면 imageio-ffmpeg의 실행 파일을 쓴다)
실행:
    python3 make_gjt_audio.py            # 이미 만든 파일은 건너뜀
    python3 make_gjt_audio.py --force    # 전부 다시 생성
참고:
    gTTS는 Google Translate의 비공식 음성 인터페이스라서 인터넷이 필요하고,
    시간이 지나면 같은 문장도 소리가 달라질 수 있다.
    그래서 생성한 파일 자체를 제출 ZIP에 함께 넣는다.
"""
import csv
import datetime
import hashlib
import importlib.metadata as md
import shutil
import subprocess
import sys
import time
import wave
from pathlib import Path

from gtts import gTTS

LANG = "en"
TLD = "com"
SLOW = False

CSV_PATH = Path("gjt_sentences.csv")
OUT_DIR = Path("audio")
MP3_DIR = OUT_DIR / "mp3"
WAV_DIR = OUT_DIR / "wav"
MANIFEST = OUT_DIR / "manifest.csv"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def wav_duration(path: Path) -> float:
    with wave.open(str(path), "rb") as w:
        return w.getnframes() / w.getframerate()


def find_ffmpeg() -> str:
    """시스템 ffmpeg를 먼저 찾고, 없으면 imageio-ffmpeg가 가져온 실행 파일을 쓴다."""
    exe = shutil.which("ffmpeg")
    if exe:
        return exe
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except ImportError:
        sys.exit(
            "ffmpeg를 찾을 수 없습니다. 아래 명령으로 설치한 뒤 다시 실행하세요.\n"
            "    python3 -m pip install imageio-ffmpeg"
        )


FFMPEG = find_ffmpeg()


def to_wav(mp3: Path, wav: Path) -> None:
    # 앞쪽 무음 제거 + 음량 맞춤 + 모노 44.1kHz 16bit
    cmd = [
        FFMPEG, "-y", "-loglevel", "error", "-i", str(mp3),
        "-af", "silenceremove=start_periods=1:start_threshold=-50dB,"
               "loudnorm=I=-23:TP=-2:LRA=7",
        "-ac", "1", "-ar", "44100", "-c:a", "pcm_s16le", str(wav),
    ]
    subprocess.run(cmd, check=True)


def main() -> None:
    force = "--force" in sys.argv
    MP3_DIR.mkdir(parents=True, exist_ok=True)
    WAV_DIR.mkdir(parents=True, exist_ok=True)

    with CSV_PATH.open(encoding="utf-8", newline="") as f:
        rows = list(csv.DictReader(f))

    gtts_version = md.version("gTTS")
    now = datetime.datetime.now().isoformat(timespec="seconds")
    manifest_rows = []

    for r in rows:
        sid, text = r["sentence_id"], r["text"]
        mp3 = MP3_DIR / f"{sid}.mp3"
        wav = WAV_DIR / f"{sid}.wav"
        if force or not mp3.exists():
            gTTS(text=text, lang=LANG, tld=TLD, slow=SLOW).save(str(mp3))
            time.sleep(1.0)  # 요청 간격
        if force or not wav.exists():
            to_wav(mp3, wav)
        manifest_rows.append({
            "sentence_id": sid,
            "text": text,
            "wav": str(wav),
            "duration_s": f"{wav_duration(wav):.3f}",
            "sha256_mp3": sha256(mp3),
            "gtts_version": gtts_version,
            "lang": LANG,
            "tld": TLD,
            "slow": SLOW,
            "generated_at": now,
        })

    with MANIFEST.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(manifest_rows[0].keys()))
        w.writeheader()
        w.writerows(manifest_rows)

    print(f"{len(manifest_rows)}개 문장 처리 완료 -> {MANIFEST}")


if __name__ == "__main__":
    main()
