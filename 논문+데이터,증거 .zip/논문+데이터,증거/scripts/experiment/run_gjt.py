#!/usr/bin/env python3
"""문법성 판단 과제(GJT) 실행 스크립트 (PsychoPy 2025.2.x)

실행
  PsychoPy 앱의 Coder에서 이 파일을 열고 Run(▶)을 누른다.
  같은 폴더에 gjt_sentences.csv 와 audio/wav/ 폴더가 있어야 한다.

진행
  1) 참여자 코드(P1~P4, 연습 점검은 TEST)와 무작위 시드를 입력
  2) 소리 점검(신호음) -> 안내 -> 연습 4문장(정오 피드백 있음) -> 본 문장 55개(피드백 없음)
  3) 문장은 한 번만 들려준다. 음성 파일 길이 + 0.1초가 지나면 응답 화면이 나오고,
     그 순간부터 반응시간을 잰다. 문장이 나오는 동안 누른 키는 무시한다.
     F = 문법에 맞음, J = 문법에 맞지 않음, Esc = 중단
  4) 본 문장 순서는 시드로 섞는다(같은 시드 -> 같은 순서). 시드는 모든 행에 기록한다.

저장
  results/<코드>_gjt_<날짜시각>.csv 에 한 시행씩 바로 저장한다(중간에 멈춰도 보존).
  TEST는 results_test/ 에 저장하며 분석에 쓰지 않는다(본 문장 6개만 진행).
  분석에서는 block == "main" 인 행만 쓴다(연습 행도 파일에 남아 있다).

PsychoPy 없이 저장 형식만 점검
  python3 run_gjt.py --dry-run     (results_dryrun/ 에 가짜 응답으로 4명 분량 생성)
"""
import argparse
import csv
import datetime
import random
import re
import sys
import wave
from pathlib import Path

BASE = Path(__file__).resolve().parent
CSV_PATH = BASE / "gjt_sentences.csv"
WAV_DIR = BASE / "audio" / "wav"

KEY_G = "f"   # 문법에 맞음
KEY_U = "j"   # 문법에 맞지 않음
KEY_MAP = "f=grammatical;j=ungrammatical"
FONT = "Apple SD Gothic Neo"   # 한글이 네모로 보이면 "AppleGothic" 또는 "Arial Unicode MS"
ITI_S = 1.0
FEEDBACK_S = 1.0
END_MARGIN_S = 0.1   # 파일 길이 + 이 시간이 지나면 응답 화면을 띄운다(재생 시작 지연 여유)
BREAK_AFTER = 28   # 본 문항 28개를 마치면 잠깐 쉼

FIELDS = [
    "participant", "session_start", "seed", "block", "trial_in_block",
    "trial_overall", "trial_start", "sentence_id", "item_id", "category",
    "grammatical", "analysis_main", "text", "key", "response_grammatical",
    "correct", "rt_s", "wav_duration_s", "sound_duration_s", "key_map",
    "psychopy_version", "audio_lib",
]

INSTR = (
    "영어 문장 듣기 과제\n\n"
    "영어 문장이 한 번씩 들립니다.\n"
    "문장이 끝나면 화면에 안내가 나옵니다.\n"
    "들은 문장이 영어 문법에 맞으면 F, 어색하거나 틀렸으면 J를 누르세요.\n"
    "문장이 나오는 동안 누른 키는 무시됩니다.\n"
    "문장이 끝난 뒤 최대한 빠르고 정확하게 답해 주세요.\n\n"
    "먼저 연습 4문장을 합니다.\n"
    "준비가 되면 스페이스바를 누르세요."
)
READY = (
    "연습이 끝났습니다.\n\n"
    "연습 문장이 중간에 끊기거나 잘 안 들렸다면\n지금 실험자에게 알려 주세요.\n\n"
    "본 과제를 시작합니다.\n준비가 되면 스페이스바를 누르세요."
)
BREAK = "잠깐 쉬어 가세요.\n\n준비가 되면 스페이스바를 누르세요."
END = "수고하셨습니다.\n과제가 끝났습니다."


class Aborted(Exception):
    pass


def wav_duration(path):
    with wave.open(str(path), "rb") as w:
        return w.getnframes() / w.getframerate()


def now_iso(ms=False):
    return datetime.datetime.now().isoformat(timespec="milliseconds" if ms else "seconds")


def load_sentences(check_audio=True):
    with CSV_PATH.open(encoding="utf-8", newline="") as f:
        rows = list(csv.DictReader(f))
    for r in rows:
        wav = WAV_DIR / f"{r['sentence_id']}.wav"
        r["wav"] = wav
        r["wav_dur"] = wav_duration(wav) if wav.exists() else None
    if check_audio:
        missing = [r["sentence_id"] for r in rows if r["wav_dur"] is None]
        if missing:
            sys.exit("음성 파일이 없습니다: " + ", ".join(missing)
                     + "\nmake_gjt_audio.py 를 먼저 실행하세요.")
    practice = [r for r in rows if r["practice"] == "1"]
    main_rows = [r for r in rows if r["practice"] == "0"]
    return practice, main_rows


def shuffled(rows, seed):
    rng = random.Random(seed)
    out = list(rows)
    rng.shuffle(out)
    return out


def make_row(meta, block, i_block, i_all, s, key, rt, sound_dur, started):
    resp = 1 if key == KEY_G else 0
    truth = int(s["grammatical"])
    wav_dur = s.get("wav_dur")
    return {
        "participant": meta["participant"],
        "session_start": meta["session_start"],
        "seed": meta["seed"],
        "block": block,
        "trial_in_block": i_block,
        "trial_overall": i_all,
        "trial_start": started,
        "sentence_id": s["sentence_id"],
        "item_id": s["item_id"],
        "category": s["category"],
        "grammatical": truth,
        "analysis_main": s["analysis_main"],
        "text": s["text"],
        "key": key,
        "response_grammatical": resp,
        "correct": int(resp == truth),
        "rt_s": f"{rt:.4f}",
        "wav_duration_s": "" if wav_dur is None else f"{wav_dur:.3f}",
        "sound_duration_s": f"{sound_dur:.3f}",
        "key_map": KEY_MAP,
        "psychopy_version": meta["psychopy_version"],
        "audio_lib": meta["audio_lib"],
    }


class ResultWriter:
    def __init__(self, path):
        path.parent.mkdir(parents=True, exist_ok=True)
        self.path = path
        self.f = path.open("w", encoding="utf-8", newline="")
        self.w = csv.DictWriter(self.f, fieldnames=FIELDS)
        self.w.writeheader()
        self.f.flush()

    def write(self, row):
        self.w.writerow(row)
        self.f.flush()

    def close(self):
        self.f.close()


def new_meta(code, seed):
    return {"participant": code, "seed": seed, "session_start": now_iso(),
            "psychopy_version": "", "audio_lib": ""}


def open_writer(out_dir, meta):
    stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    return ResultWriter(out_dir / f"{meta['participant']}_gjt_{stamp}.csv")


def summarize(path):
    with path.open(encoding="utf-8", newline="") as f:
        rows = [r for r in csv.DictReader(f) if r["block"] == "main"]
    if not rows:
        print("본 문항 기록이 없습니다.")
        return
    acc = sum(int(r["correct"]) for r in rows)
    rts = sorted(float(r["rt_s"]) for r in rows)
    median = rts[len(rts) // 2] if len(rts) % 2 else (rts[len(rts) // 2 - 1] + rts[len(rts) // 2]) / 2
    print(f"본 문항 {len(rows)}개: 정답 {acc}개 ({acc / len(rows):.1%}), 반응시간 중앙값 {median:.3f}초")


def ask_session():
    from psychopy import gui
    info = {"participant": "P1", "seed": random.SystemRandom().randrange(1, 10**6)}
    dlg = gui.DlgFromDict(info, title="GJT 시작", order=["participant", "seed"])
    if not dlg.OK:
        sys.exit("취소했습니다.")
    code = str(info["participant"]).strip().upper()
    if not re.fullmatch(r"P[1-4]|TEST", code):
        sys.exit("참여자 코드는 P1~P4 또는 TEST 만 가능합니다: " + code)
    try:
        seed = int(info["seed"])
    except (TypeError, ValueError):
        sys.exit("시드는 정수여야 합니다.")
    previous = sorted((BASE / "results").glob(f"{code}_gjt_*.csv")) if code != "TEST" else []
    if previous:
        confirm = gui.Dlg(title="확인")
        confirm.addText(f"{code} 의 결과 파일이 이미 있습니다 ({previous[-1].name}).\n"
                        "기존 파일은 지워지지 않습니다. 새 세션을 시작할까요?")
        confirm.show()
        if not confirm.OK:
            sys.exit("취소했습니다.")
    return code, seed


def run_psychopy(meta, practice, order, writer, windowed):
    import psychopy
    from psychopy import core, sound, visual
    from psychopy.hardware import keyboard

    meta["psychopy_version"] = psychopy.__version__
    meta["audio_lib"] = str(getattr(sound, "audioLib", ""))

    win = visual.Window(fullscr=not windowed, size=(1280, 720), color=(-1, -1, -1),
                        units="height", allowGUI=False)
    try:
        kb = keyboard.Keyboard()
        msg = visual.TextStim(win, text="", font=FONT, color="white", height=0.045, wrapWidth=1.5)

        def show(text, height=0.045):
            msg.text = text
            msg.height = height
            msg.draw()
            win.flip()

        def wait_space(text):
            show(text)
            if kb.waitKeys(keyList=["space", "escape"], waitRelease=False)[0].name == "escape":
                raise Aborted()

        snds = {s["sentence_id"]: sound.Sound(str(s["wav"])) for s in practice + order}
        mismatch = []
        for s in practice + order:
            d = snds[s["sentence_id"]].getDuration()
            if s["wav_dur"] is not None and abs(d - s["wav_dur"]) > 0.05:
                mismatch.append(f"{s['sentence_id']}: PsychoPy {d:.3f}s / 파일 {s['wav_dur']:.3f}s")
        if mismatch:
            print(f"경고: {len(mismatch)}개 문장에서 PsychoPy가 읽은 길이가 파일 길이와 다릅니다. "
                  "이 스크립트는 파일 길이를 기준으로 재생을 기다립니다.")
            print("  예) " + "; ".join(mismatch[:3]))

        def trial(s, block, i_block, i_all, feedback):
            snd = snds[s["sentence_id"]]
            dur = snd.getDuration()
            # 기다리는 시간은 PsychoPy가 알려 주는 길이가 아니라 파일에서 읽은 실제 길이를 기준으로 한다.
            # 재생이 끝나기 전에 stop()으로 소리를 끊는 일이 없도록 하기 위해서다.
            play_s = (s["wav_dur"] if s["wav_dur"] is not None else dur) + END_MARGIN_S
            started = now_iso(ms=True)
            show("+", 0.08)
            snd.play()
            t0 = core.getTime()
            while core.getTime() - t0 < play_s:
                if kb.getKeys(keyList=["escape"], waitRelease=False):
                    snd.stop()
                    raise Aborted()
                core.wait(0.005)
            kb.clearEvents()
            msg.text = f"문법에 맞음: {KEY_G.upper()}        맞지 않음: {KEY_U.upper()}"
            msg.height = 0.06
            msg.draw()
            win.callOnFlip(kb.clock.reset)
            win.flip()
            key = kb.waitKeys(keyList=[KEY_G, KEY_U, "escape"], waitRelease=False, clear=False)[0]
            if key.name == "escape":
                raise Aborted()
            row = make_row(meta, block, i_block, i_all, s, key.name, key.rt, dur, started)
            writer.write(row)
            if feedback:
                if row["correct"] == 1:
                    show("정답입니다")
                elif int(s["grammatical"]) == 1:
                    show("아닙니다. 문법에 맞는 문장이었습니다")
                else:
                    show("아닙니다. 문법에 맞지 않는 문장이었습니다")
                core.wait(FEEDBACK_S)
            win.flip()
            core.wait(ITI_S)

        def sound_check():
            # 신호음(문장 자극이 아님)으로 소리 장치를 먼저 깨우고, 끊김 없이 들리는지 확인한다.
            tone = sound.Sound("A", secs=1.5, volume=0.2)
            wait_space("소리 점검\n\n신호음이 나옵니다.\n스페이스바를 누르면 재생됩니다.")
            while True:
                tone.play()
                core.wait(1.5 + END_MARGIN_S)
                show("신호음이 끝까지 또렷하게 들렸으면 스페이스,\n끊기거나 안 들렸으면 R 을 눌러 다시 들으세요.")
                k = kb.waitKeys(keyList=["space", "r", "escape"], waitRelease=False)[0].name
                if k == "escape":
                    raise Aborted()
                if k == "space":
                    return

        sound_check()
        wait_space(INSTR)
        for i, s in enumerate(practice, 1):
            trial(s, "practice", i, i, True)
        wait_space(READY)
        for i, s in enumerate(order, 1):
            trial(s, "main", i, len(practice) + i, False)
            if i == BREAK_AFTER and len(order) > BREAK_AFTER:
                wait_space(BREAK)
        show(END)
        core.wait(2.0)
    finally:
        win.close()


def run_dry(meta, practice, order, writer):
    meta["psychopy_version"] = "dry-run"
    meta["audio_lib"] = "none"
    rng = random.Random(meta["seed"])
    n = 0
    for block, rows in (("practice", practice), ("main", order)):
        for i, s in enumerate(rows, 1):
            n += 1
            key = rng.choice([KEY_G, KEY_U])
            writer.write(make_row(meta, block, i, n, s, key, rng.uniform(0.4, 1.8), 0.0, now_iso(ms=True)))


def main():
    ap = argparse.ArgumentParser(description="문법성 판단 과제(GJT)")
    ap.add_argument("--dry-run", action="store_true", help="PsychoPy 없이 가짜 응답으로 저장 형식만 점검")
    ap.add_argument("--windowed", action="store_true", help="전체 화면 대신 창으로 실행")
    args = ap.parse_args()

    if args.dry_run:
        practice, main_rows = load_sentences(check_audio=False)
        for i, code in enumerate(["P1", "P2", "P3", "P4"], 1):
            seed = 1000 + i
            meta = new_meta(code, seed)
            writer = open_writer(BASE / "results_dryrun", meta)
            try:
                run_dry(meta, practice, shuffled(main_rows, seed), writer)
            finally:
                writer.close()
            print(f"{code}: {writer.path.name}")
            summarize(writer.path)
        return

    practice, main_rows = load_sentences(check_audio=True)
    code, seed = ask_session()
    order = shuffled(main_rows, seed)
    if code == "TEST":
        order = order[:6]
    meta = new_meta(code, seed)
    writer = open_writer(BASE / ("results_test" if code == "TEST" else "results"), meta)
    try:
        run_psychopy(meta, practice, order, writer, windowed=args.windowed or code == "TEST")
        print(f"완료: {writer.path}")
    except Aborted:
        print(f"중단했습니다. 지금까지의 기록은 {writer.path} 에 남아 있습니다.")
        return
    finally:
        writer.close()
    summarize(writer.path)


if __name__ == "__main__":
    main()
