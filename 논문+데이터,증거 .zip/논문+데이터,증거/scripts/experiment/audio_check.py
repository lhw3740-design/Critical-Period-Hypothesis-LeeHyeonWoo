#!/usr/bin/env python3
"""소리 재생 점검 (PsychoPy Coder에서 열어 Run)

audio/wav 의 문장 4개를 끝까지 재생하면서, 아래 값을 콘솔에 출력한다.
  - 파일 길이(wave 모듈로 읽은 값)와 PsychoPy가 읽은 길이(getDuration)
  - 사용 중인 소리 라이브러리
소리가 문장 끝까지 들리는지 귀로 확인하고, 콘솔에 나온 줄을 그대로 알려 준다.
"""
import wave
from pathlib import Path

import psychopy
from psychopy import core, prefs, sound

BASE = Path(__file__).resolve().parent
print("PsychoPy", psychopy.__version__, "| 설정된 audioLib:", prefs.hardware["audioLib"])

for name in ["P1", "P2", "01a", "17b"]:
    path = BASE / "audio" / "wav" / f"{name}.wav"
    with wave.open(str(path), "rb") as w:
        rate, secs = w.getframerate(), w.getnframes() / w.getframerate()
    snd = sound.Sound(str(path))
    print(f"{name}: 파일 {secs:.3f}s ({rate} Hz) / getDuration {snd.getDuration():.3f}s "
          f"/ 실제 사용 audioLib: {getattr(sound, 'audioLib', '?')}")
    snd.play()
    core.wait(secs + 0.3)      # 끝까지 기다린다(중간에 stop() 하지 않음)
    core.wait(0.7)

print("끝. 4문장이 끝까지 들렸는지 알려 주세요.")
core.quit()
