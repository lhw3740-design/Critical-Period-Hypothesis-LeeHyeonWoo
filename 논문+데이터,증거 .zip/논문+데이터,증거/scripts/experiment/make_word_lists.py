#!/usr/bin/env python3
"""녹음용 단어 목록 생성기

h-V-d 단어 12개를 블록마다 한 번씩, 무작위 순서로 배열한다.
참여자 4명 x (연습 블록 b00 + 본 블록 b01~b03) = 16블록.
시드는 "기본시드-참여자-블록" 문자열로 정하므로, 기본시드가 같으면 목록도 항상 같다.
같은 단어가 연달아 나오지 않도록 블록 경계도 확인한다.

실행:  python3 make_word_lists.py [기본시드]      (기본시드를 안 쓰면 20261013)
출력:  recording_lists/recording_lists.csv   (모든 시행: 참여자, 블록, 순서, 단어, 시드)
       recording_lists/recording_lists.txt   (인쇄·화면용 목록)
"""
import csv
import random
import sys
from pathlib import Path

BASE = Path(__file__).resolve().parent
OUT_DIR = BASE / "recording_lists"

# (단어, Hillenbrand et al. 1995 모음 코드, IPA)
WORDS = [
    ("heed", "iy", "i"), ("hid", "ih", "ɪ"), ("hayed", "ei", "e"), ("head", "eh", "ɛ"),
    ("had", "ae", "æ"), ("hod", "ah", "ɑ"), ("hawed", "aw", "ɔ"), ("hoed", "oa", "o"),
    ("hood", "oo", "ʊ"), ("who'd", "uw", "u"), ("hud", "uh", "ʌ"), ("heard", "er", "ɝ"),
]
PARTICIPANTS = ["P1", "P2", "P3", "P4"]
BLOCKS = [f"b{i:02d}" for i in range(0, 4)]   # b00 = 연습(분석 제외), b01~b03 = 본 녹음


def make_rows(base_seed):
    rows = []
    for p in PARTICIPANTS:
        prev_last = None
        for b in BLOCKS:
            seed = f"{base_seed}-{p}-{b}"
            rng = random.Random(seed)
            order = list(WORDS)
            while True:
                rng.shuffle(order)
                if prev_last is None or order[0][0] != prev_last:
                    break
            prev_last = order[-1][0]
            for pos, (word, code, ipa) in enumerate(order, 1):
                rows.append({
                    "participant": p, "block": b,
                    "block_type": "practice" if b == "b00" else "main",
                    "position": pos, "word": word, "vowel_code": code, "ipa": ipa,
                    "seed": seed,
                })
    return rows


def check(rows):
    """건수·중복 점검. 어긋나면 AssertionError."""
    words = {w for w, _, _ in WORDS}
    for p in PARTICIPANTS:
        seq = [r["word"] for r in rows if r["participant"] == p]
        assert len(seq) == 12 * len(BLOCKS), p
        assert all(a != b for a, b in zip(seq, seq[1:])), f"{p}: 같은 단어가 연달아 나옴"
        for b in BLOCKS:
            blk = [r["word"] for r in rows if r["participant"] == p and r["block"] == b]
            assert sorted(blk) == sorted(words), f"{p} {b}: 단어가 한 번씩이 아님"
        main = [r for r in rows if r["participant"] == p and r["block_type"] == "main"]
        for w in words:
            assert sum(1 for r in main if r["word"] == w) == 3, f"{p} {w}: 본 녹음 3회가 아님"


def write_outputs(rows):
    OUT_DIR.mkdir(exist_ok=True)
    with (OUT_DIR / "recording_lists.csv").open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    lines = []
    for p in PARTICIPANTS:
        lines.append(f"==================== {p} ====================\n")
        for b in BLOCKS:
            kind = "연습(분석 제외)" if b == "b00" else "본 녹음"
            lines.append(f"[{p} {b}  {kind}]")
            for r in rows:
                if r["participant"] == p and r["block"] == b:
                    lines.append(f"  {r['position']:2d}. {r['word']}")
            lines.append("")
    (OUT_DIR / "recording_lists.txt").write_text("\n".join(lines), encoding="utf-8")


def main():
    base_seed = sys.argv[1] if len(sys.argv) > 1 else "20261013"
    rows = make_rows(base_seed)
    check(rows)
    write_outputs(rows)
    main_n = sum(1 for r in rows if r["block_type"] == "main")
    print(f"기본시드 {base_seed}: 전체 {len(rows)}행 (본 녹음 {main_n}행) -> {OUT_DIR}")


if __name__ == "__main__":
    main()
