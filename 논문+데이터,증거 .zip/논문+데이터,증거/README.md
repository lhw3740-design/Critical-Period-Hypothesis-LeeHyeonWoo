# 재현 자료: 영어 최초 노출 연령과 성인기 영어 문법성 판단·모음 음향 특성 (가족 4명 사례 연구)

## 논문
`논문_가족4명_사례연구.pdf`(Word 판: `.docx`)가 제출 논문 본문이다. 아래 재현 과정은 이 논문의 표·그림 수치를 원자료에서 다시 만든다.

## 한 번에 재현하기
```
pip install praat-parselmouth==0.4.7 numpy scipy
bash run_all.sh
```
`out/`에 모든 결과를 다시 만들고 `results/`와 비교한다. 마지막 줄에 "재현 확인"이 나오면 논문의 수치가 원자료에서 그대로 나온 것이다.

## 폴더
| 경로 | 내용 |
|---|---|
| `data/gjt/` | GJT 원자료 4개(PsychoPy 2025.2.4 출력, 참여자별 seed 열 포함) |
| `data/recordings/` | 모음 녹음 12개(P1~P4 × 본 블록 3개, 16 kHz 모노). 연습 블록 b00은 분석 제외 |
| `data/survey/` | 영어 사용 설문 원본 4개 → `data/participants.csv`로 정리 |
| `data/hillenbrand/` | Hillenbrand et al. (1995) 공개 자료: 성인 음성(men.zip, women.zip), timedata.dat, vowdata.dat |
| `data/gjt_sentences.csv` | GJT 문장 59개(연습 4 + 본 55), 정문 여부·범주 |
| `data/recording_lists.csv` | 블록별 단어 순서(시드 20261013) |
| `corrections/` | 연구자 청취 확인에 따른 보정: P2_b03 hod 구간(TextGrid), P2_b03 hoed 제외(exclusions.csv) |
| `textgrids_auto/` | 자동 검출한 모음 구간(보정 전, Praat에서 열어 확인용) |
| `scripts/experiment/` | 실험 실행: 단어 목록 생성, TTS 음성 생성, 음량 점검, GJT 실행 |
| `scripts/analysis/` | 분석: GJT 채점, 원어민 재측정, 가족 측정, 거리·판정, 공개 수치 비교, TextGrid 생성 |
| `results/` | 논문에 쓴 결과. `final/`이 최종(보정 반영), `auto_before_correction/`은 보정 전 |
| `docs/` | 사전 계획서(변경 기록 포함), 녹음 절차서, 설문지 |

## 논문 수치와 파일의 대응
| 논문 | 파일 |
|---|---|
| 3.4.1절 그림 1a~1d, 2 | `results/figures/` (`scripts/analysis/make_figures.py`로 생성) |
| 4절 판정표, 그림 4 | `results/final/family_participant_summary.csv`, `family_block_distances.csv` |
| 4.1절 GJT 표, 그림 3, 부록 B | `results/gjt_summary.csv`, `gjt_by_category.csv` |
| 4.2절 모음별 거리, 라벨 정렬률 | `results/final/family_vowel_distances.csv`, `label_check.csv` |
| 4.2절 원어민 90백분위 | `results/final/native_distances.csv` |
| 4.3절 측정 도구 차이 | `results/public_vs_praat.csv` |
| 부록 C 민감도 분석 | `results/sensitivity/sensitivity_static.csv` (`sensitivity.py`) |

## 도구
분석: Python parselmouth 0.4.7(내장 Praat 엔진 6.1.38). 녹음: Praat 7.0.02. GJT: PsychoPy 2025.2.4, gTTS(lang=en, tld=com).
