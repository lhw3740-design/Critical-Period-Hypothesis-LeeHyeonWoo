#!/usr/bin/env bash
# 논문의 모든 수치를 원자료에서 다시 만든다. 결과는 out/ 에 쓰고 results/ 와 비교한다.
# 필요: Python 3, praat-parselmouth==0.4.7, numpy, scipy
set -euo pipefail
cd "$(dirname "$0")"
S=scripts/analysis; O=out; W=$O/work
rm -rf "$O"; mkdir -p "$W/hb/dat" "$O/final" "$O/auto_before_correction"
# 1) GJT
python3 -I $S/analyze_gjt.py data/gjt data/gjt_sentences.csv $O
# 2) 원어민 재측정 (Hillenbrand 성인 1,116개)
unzip -q -o data/hillenbrand/men.zip -d "$W/hb/men"; unzip -q -o data/hillenbrand/women.zip -d "$W/hb/women"
cp data/hillenbrand/timedata.dat data/hillenbrand/vowdata.dat "$W/hb/dat/"
python3 -I $S/measure_natives.py "$W/hb" $O/native_formants_praat.csv
python3 -I $S/compare_public.py $O/native_formants_praat.csv $O/public_vs_praat.csv > /dev/null
# 3) 가족 측정: 자동 구간(보정 전)과 보정본(최종)
python3 -I $S/measure_family.py data/recordings data/recording_lists.csv $O/family_formants.csv
python3 -I $S/measure_family.py data/recordings data/recording_lists.csv $O/family_formants_corrected.csv \
  --textgrids corrections/textgrids --exclude corrections/exclusions.csv
# 4) 거리·판정
python3 -I $S/compute_distances.py $O/native_formants_praat.csv $O/family_formants.csv data/participants.csv $O/gjt_summary.csv $O/auto_before_correction > /dev/null
python3 -I $S/compute_distances.py $O/native_formants_praat.csv $O/family_formants_corrected.csv data/participants.csv $O/gjt_summary.csv $O/final | sed -n '/판정/,$p'
# 5) 그림 1a~1d, 2 (가족 대 원어민 스펙트로그램, 정규화 모음 공간)
mkdir -p $O/figures && python3 -I $S/make_figures.py data/recordings "$W/hb" $O/family_formants_corrected.csv $O/native_formants_praat.csv $O/figures 2>/dev/null
# 6) 부록 C 민감도 분석(탐색적, 몇 분 걸림)
mkdir -p $O/sensitivity && python3 -I $S/sensitivity.py data/recordings "$W/hb" $O/family_formants_corrected.csv $O/native_formants_praat.csv data/participants.csv $O/gjt_summary.csv $O/sensitivity > /dev/null
# 7) results/ 와 비교 (그림은 PNG라 비교에서 뺌)
rm -rf "$W"
if diff -rq -x figures results "$O" > /dev/null; then echo "재현 확인: out/ 이 results/ 와 같습니다"; else echo "차이 있음:"; diff -rq -x figures results "$O" || true; fi
